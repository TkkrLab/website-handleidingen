In file "lightburn_color_palet.svg" are all the colors that Lightburn use. You can open this file in your favoriet vector editor and use the colors to make your own pallet.

* Illustrator *
Import the "lightburn_color_palet.ai" as a color swatch into Illustrator.


* Inkscape *
Place the "LightBurn.gpl" in the palletes directory of Inkscape. Normaly this would be :

Windowns
C:\Program Files\Inkscape\share\palettes

Mac OS 
/Applications/Inkscape92.app/Contents/Resources/share/inkscape/palettes/inkscape.gpl
Or if you installed it with MacPorts
/opt/local/share/inkscape/palettes/inkscape.gpl